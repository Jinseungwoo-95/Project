#include "Map2.h"



void Map2::Init()
{
}

void Map2::Update(float dt)
{
}

void Map2::Render(HDC hdc, float dt)
{
}

void Map2::Destroy()
{
}

Map2::Map2()
{
}


Map2::~Map2()
{
}
