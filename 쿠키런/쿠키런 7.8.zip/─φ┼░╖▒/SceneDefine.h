#pragma once

#include "MenuScene.h"
#include "ClearScene.h"
#include "GameOverScene.h"
#include "GameScene.h"
#include "GameScene2.h"